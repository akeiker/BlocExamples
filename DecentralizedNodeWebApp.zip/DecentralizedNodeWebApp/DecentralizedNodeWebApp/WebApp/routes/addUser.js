
module.exports.newUser = function (req, res) {
    res.render('addUser', { title: 'Got block Page' });
};

module.exports.addUser = function (req, res) {
    console.log(req.body);
    res.render('userAdded', {
        title: 'Welcome to first BlockApps',
        pagetitle: 'Page Title is working',
        name: 'Jagdish: ' + req.body.user,
        addr: 'tgfgfffdfdfdsfdfdsrewds3rfdfrtrfgd54',
        message: 'Your request submitted'
    });
};



