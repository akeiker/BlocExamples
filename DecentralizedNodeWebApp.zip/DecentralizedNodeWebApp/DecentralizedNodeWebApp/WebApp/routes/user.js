﻿var blcapps = require('blockapps-js');

var blkapps = require('blockapps-api')('config.yaml');
const Promise = require('bluebird');

/*
 * GET users listing.
 */

exports.list = function (req, res) {

    //var Account = blcapps.ethbase.Account;

    // The "0x" prefix is optional for addresses
    var address = "a02ff24f706dc2d122953d83a229011f4a29eb78";

    //Account(address).balance.then(function (balance) {
    //    var test = balance.toString();
    //    // In here, "balance" is a big-integer you can manipulate directly.

    //    res.send("respond with a resource: " + test);

    //});

    blkapps.strato.home().then(function (error, result) {
        var te = result;
        console.log(result.toString());
    });

    blkapps.strato.account(address).then(function (error, myResult) {
        var myres = result;
        console.log(myResult.toString());
    });

   // res.send("respond with a resource");
};