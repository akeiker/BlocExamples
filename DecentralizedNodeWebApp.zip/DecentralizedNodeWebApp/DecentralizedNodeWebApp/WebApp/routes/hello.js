﻿module.exports = function (req, res) {
    res.send("<h1>Hello, World!</h1>");
};