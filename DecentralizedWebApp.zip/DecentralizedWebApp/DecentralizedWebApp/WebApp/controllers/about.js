﻿//var mongoose = require('mongoose')
//var Video = require('../models/user');
module.exports.controller = function (app) {

    /**
     * About page route
     */
    app.get('/about', function (req, res) {
        // any logic goes here
        res.render('about', { title: 'About', year: new Date().getFullYear(), message: 'Your application description page' });
    });

}