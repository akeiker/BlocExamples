﻿//var mongoose = require('mongoose')
//var Video = require('../models/user');
module.exports.controller = function (app)
{
    /**
     * bloc example 1 page route
     */
    app.get('/bloc_addEther', function (req, res)
    {
        // any logic goes here
        res.render('bloc_addEther', { title: 'bloc_addEther', year: new Date().getFullYear(), message: 'Your application description page '});

        console.log('STATUS: ' + res.statusCode);
        console.log('HEADERS: ' + JSON.stringify(res.headers));
    });


   /*
    * Post form request
    */
    app.post('/bloc_addEther', function (req, res) {
        
        var etherAmount = req.body.ether_amount;
        console.log(etherAmount);
        var ethbase = require('blockapps-js').ethbase
        var Transaction = ethbase.Transaction;
        var Int = ethbase.Int;
        var ethValue = ethbase.Units.ethValue;

        var addressTo = "f82a9daa33192550956612db5f9c2055042bdbb4";
        var privkeyFrom = "1634e705d8ac0e311273d8878bcd1543";

        // This statement doesn't actually send a transaction; it just sets it up.
        var valueTX = Transaction({ "value": ethValue(1).in("ether") });

        valueTX.send(privkeyFrom, addressTo).then(function (txResult) {
                if (txResult.message === "Success!")
                    res.send('Successfully added!');
                else
                    res.send('Failed on adding!' + txResult.message);
            // txResult.message is either "Success!" or an error message
            // For this transaction, the error would be about insufficient balance.

        });


        //res.send('Submitted Ether');

    });

}
