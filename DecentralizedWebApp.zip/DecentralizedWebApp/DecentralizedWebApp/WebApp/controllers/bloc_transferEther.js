﻿//var mongoose = require('mongoose')
//var Video = require('../models/user');
module.exports.controller = function (app)
{
    /**
     * bloc example 1 page route
     */
    app.get('/bloc_transferEther', function (req, res)
    {
        // any logic goes here
        res.render('bloc_transferEther', { title: 'bloc_transferEther', year: new Date().getFullYear(), message: 'Your application description page '});

        console.log('STATUS: ' + res.statusCode);
        console.log('HEADERS: ' + JSON.stringify(res.headers));
    });


   /*
    * Post form request
    */
    app.post('/bloc_transferEther', function (req, res) {
        
        var etherAmount = req.body.ether_amount;
        var etherFrom = req.body.ether_from;
        var etherTo = req.body.ether_to;

        console.log(etherAmount);
        var ethbase = require('blockapps-js').ethbase;
        var Transaction = ethbase.Transaction;
        var Int = ethbase.Int;
        var ethValue = ethbase.Units.ethValue;
        
        // This statement doesn't actually send a transaction; it just sets it up.
        var valueTX = Transaction({ "value": ethValue(etherAmount).in("ether") });

        valueTX.send(etherFrom, etherTo).then(function (txResult) {
                if (txResult.message === "Success!")
                    res.send('Successfully added!');
                else
                    res.send('Failed on adding!' + txResult.message);
            // txResult.message is either "Success!" or an error message
            // For this transaction, the error would be about insufficient balance.

        });


        //res.send('Submitted Ether');

    });

}
