﻿//var mongoose = require('mongoose')
//var Video = require('../models/user');
module.exports.controller = function (app) {

    /**
     * About page route
     */
    app.get('/', function (req, res) {
        // any logic goes here
        res.render('index', { title: 'Index', year: new Date().getFullYear(), message: 'Home page' });
    });

}