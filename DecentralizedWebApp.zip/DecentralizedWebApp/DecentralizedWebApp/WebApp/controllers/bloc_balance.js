﻿//var mongoose = require('mongoose')
//var Video = require('../models/user');
module.exports.controller = function (app)
{
    /**
     * bloc example 1 page route
     */
    app.get('/bloc_balance', function (req, res)
    {

        var Amt;

        var Account = require('blockapps-js').ethbase.Account;

        // Contract Address
        var contractAddress = 'e0d4bb99b8671f17bf4831dc984aac0d5c14960b';

        var testAddress = '4465803d4bba2e68f032f83464864fc448b2517c';

        // User Address
        var userAddress = 'f82a9daa33192550956612db5f9c2055042bdbb4';

        Account(testAddress).balance.then(function (balance) {
            // In here, "balance" is a big-integer you can manipulate directly.
            Amt = balance.words[0] + balance.words[1] + balance.words[2];

            // any logic goes here
            res.render('bloc_balance', {
                title: 'bloc_balance',
                balanceAmt: balance.toString(),
                year: new Date().getFullYear(), message: 'Your application description page '
            });
        });
        
    });




}
